# Claude Voice Bridge 🎙️🚲

A hands-free voice interface for Claude Code — talk to Claude from your bike (or anywhere)
using a Bluetooth remote, your phone, and headphones.

## How It Works

```
[BT Remote on handlebars]
        │ (HID button press)
        ▼
[Android Phone] ── voice record ──► STT ──► Telegram Bot API
        │                                        │
        │                                        ▼
        │                              [Claude Code Session]
        │                              (running on home PC with
        │                               --channels telegram)
        │                                        │
        │                                        ▼
        │                              Claude processes + replies
        │                              via Telegram bot sendMessage
        │                                        │
        ◄─── Telegram notification ◄─────────────┘
        │
        ▼
  [TTS through headphones]
```

## Two Paths — Pick One

| | **Tasker (30 min setup)** | **React Native App (full build)** |
|---|---|---|
| Effort | No coding, config only | ~2hrs to build |
| Polish | Functional but rough | Clean UI, smooth UX |
| BLE Remote | Via volume key remap | Native volume key intercept |
| Best for | Testing the concept today | Daily riding use |

---

## Prerequisites (Both Paths)

### 1. Claude Code + Telegram Channel (Home Machine)

```bash
# Ensure Claude Code >= 2.1.80
claude --version

# Install Bun (required for channel plugins)
curl -fsSL https://bun.sh/install | bash

# Open Claude Code and install the Telegram plugin
claude
# Inside Claude Code REPL:
/plugin install telegram@claude-plugins-official
```

**Create your Telegram bot:**
1. Open Telegram on your phone, find **@BotFather**
2. Send `/newbot`, give it a name (e.g. "Claude Bike Brain")
3. Copy the bot token BotFather gives you

```bash
# Configure the token
/channel configure telegram@claude-plugins-official
# Paste your bot token when prompted

# Exit and restart with channels enabled
claude --channels plugin:telegram@claude-plugins-official
```

**Pair your phone:**
1. Open Telegram, find your new bot
2. Send it any message
3. It replies with a pairing code — enter it in your terminal
4. You're connected! Test by sending a message in Telegram.

**Keep the session alive** (important for riding):
```bash
# Use tmux or screen so the session survives
tmux new -s claude-bike
claude --channels plugin:telegram@claude-plugins-official

# Detach: Ctrl+B, then D
# Reattach: tmux attach -t claude-bike
```

### 2. Telegram App on Your Phone
Install Telegram if you don't have it. You need it for notifications.

### 3. Bluetooth Remote
Any cheap BT remote/shutter button works. Most send volume key events.
Recommended: search "Bluetooth camera remote" on Amazon (~$5-10).
Pair it with your phone via Bluetooth settings.

---

## Path A: Tasker Quick-Start

See [tasker/README.md](tasker/README.md) for complete Tasker setup instructions.

---

## Path B: React Native App

### Setup

```bash
# Install dependencies
npx react-native init ClaudeVoiceBridge --template react-native-template-typescript
cd ClaudeVoiceBridge

# Copy source files from this repo into the project, then:
npm install \
  @react-native-voice/voice \
  react-native-tts \
  @react-native-async-storage/async-storage \
  react-native-background-actions \
  react-native-volume-manager

# For Android, link native modules
cd android && ./gradlew clean && cd ..

npx react-native run-android
```

### Configuration
On first launch, the app will show a setup screen. Enter:
- **Bot Token**: The token from BotFather
- **Chat ID**: Send `/start` to your bot, then check the Telegram Bot API:
  `https://api.telegram.org/bot<TOKEN>/getUpdates` — your chat_id is in the response.

### Usage
1. Start Claude Code with `--channels` on your home machine
2. Open the app on your phone
3. Press the big button (or your BT remote's volume key) to start talking
4. Press again to stop — your message is transcribed and sent to Claude
5. Claude's response plays through your headphones via TTS

### Architecture Notes

**Sending messages**: The app records audio, uses Android's built-in speech
recognition (no API keys needed), and sends the transcribed text directly to
the Telegram Bot HTTP API. The Claude Code channel plugin picks these up.

**Receiving responses**: When Claude replies through the bot, a Telegram
notification appears on your phone. The app uses Android's
NotificationListenerService to intercept these notifications, extract the
text, and speak it via TTS. This avoids conflicts with Claude Code's own
getUpdates polling.

**Bluetooth remote**: Most cheap BT remotes send hardware volume key events.
The app intercepts these using react-native-volume-manager. A volume-up
press toggles recording on/off. Your actual media volume is preserved.

---

## Tips for Riding

- **Keep your phone mounted** on your handlebars or in a jersey pocket
- **Use bone-conduction headphones** (like Shokz) so you can still hear traffic
- **Set TTS speech rate** to 1.2-1.5x for faster responses
- **Test at home first** before taking it on the road
- Claude Code session MUST be running on your home machine while you ride
- If you lose cell signal, messages queue and send when you reconnect

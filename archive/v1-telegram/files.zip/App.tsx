/**
 * Claude Voice Bridge
 *
 * A hands-free voice interface for Claude Code via Telegram channels.
 * Press a button (on-screen or BT remote) → speak → Claude hears you.
 * Claude responds → TTS plays through your headphones.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  Animated,
  Vibration,
  Alert,
  Linking,
  AppState,
} from 'react-native';
import Voice, {
  SpeechResultsEvent,
  SpeechErrorEvent,
} from '@react-native-voice/voice';
import Tts from 'react-native-tts';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  VolumeManager,
} from 'react-native-volume-manager';
import { TelegramService, TelegramConfig } from './src/services/telegram';

// ─────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────

type Screen = 'setup' | 'main';

interface ConversationEntry {
  role: 'user' | 'claude';
  text: string;
  timestamp: number;
}

// ─────────────────────────────────────────────────────
// Storage keys
// ─────────────────────────────────────────────────────

const STORAGE_KEYS = {
  BOT_TOKEN: '@cvb_bot_token',
  CHAT_ID: '@cvb_chat_id',
  TTS_RATE: '@cvb_tts_rate',
  SETUP_COMPLETE: '@cvb_setup_complete',
};

// ─────────────────────────────────────────────────────
// App
// ─────────────────────────────────────────────────────

const App: React.FC = () => {
  // Navigation
  const [screen, setScreen] = useState<Screen>('setup');
  const [loading, setLoading] = useState(true);

  // Setup form
  const [botToken, setBotToken] = useState('');
  const [chatId, setChatId] = useState('');
  const [setupError, setSetupError] = useState('');
  const [botName, setBotName] = useState('');

  // Main screen state
  const [isListening, setIsListening] = useState(false);
  const [partialText, setPartialText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [conversation, setConversation] = useState<ConversationEntry[]>([]);
  const [ttsRate, setTtsRate] = useState(1.2);

  // Refs
  const telegramRef = useRef<TelegramService | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const scrollRef = useRef<ScrollView>(null);

  // ─────────────────────────────────────────────────
  // Init: load saved config
  // ─────────────────────────────────────────────────

  useEffect(() => {
    (async () => {
      try {
        const [token, cid, rate, setupDone] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.BOT_TOKEN),
          AsyncStorage.getItem(STORAGE_KEYS.CHAT_ID),
          AsyncStorage.getItem(STORAGE_KEYS.TTS_RATE),
          AsyncStorage.getItem(STORAGE_KEYS.SETUP_COMPLETE),
        ]);

        if (token) setBotToken(token);
        if (cid) setChatId(cid);
        if (rate) setTtsRate(parseFloat(rate));

        if (setupDone === 'true' && token && cid) {
          await initServices(token, cid);
          setScreen('main');
        }
      } catch (e) {
        console.warn('Failed to load config:', e);
      }
      setLoading(false);
    })();

    return () => {
      Voice.destroy();
      Tts.stop();
      telegramRef.current?.destroy();
    };
  }, []);

  // ─────────────────────────────────────────────────
  // Initialize services
  // ─────────────────────────────────────────────────

  const initServices = async (token: string, cid: string) => {
    // --- Voice recognition ---
    Voice.onSpeechResults = onSpeechResults;
    Voice.onSpeechPartialResults = onSpeechPartialResults;
    Voice.onSpeechError = onSpeechError;
    Voice.onSpeechEnd = onSpeechEnd;

    // --- TTS ---
    Tts.setDefaultRate(ttsRate);
    Tts.setDefaultPitch(1.0);
    Tts.setDefaultLanguage('en-US');
    // Route TTS to music stream (= headphones)
    Tts.setDucking(true);

    Tts.addEventListener('tts-start', () => setIsSpeaking(true));
    Tts.addEventListener('tts-finish', () => setIsSpeaking(false));
    Tts.addEventListener('tts-cancel', () => setIsSpeaking(false));

    // --- Telegram ---
    const telegram = new TelegramService({ botToken: token, chatId: cid });
    telegramRef.current = telegram;

    telegram.onResponse((text: string) => {
      handleClaudeResponse(text);
    });

    // Start polling as fallback (notification listener is primary)
    telegram.startPolling();
    setIsConnected(true);

    // --- Volume button intercept (for BT remote) ---
    setupVolumeButtonListener();
  };

  // ─────────────────────────────────────────────────
  // Volume button listener (BT remote support)
  // ─────────────────────────────────────────────────

  const volumeListenerRef = useRef<boolean>(false);

  const setupVolumeButtonListener = () => {
    // Listen for volume button presses
    // Most cheap BT remotes send volume-up events
    const listener = VolumeManager.addVolumeListener((result) => {
      // When a volume event fires, toggle recording
      // We suppress the actual volume change
      if (!volumeListenerRef.current) {
        volumeListenerRef.current = true;
        // Debounce: ignore events for 500ms after triggering
        setTimeout(() => {
          volumeListenerRef.current = false;
        }, 500);

        toggleListening();
      }
    });

    // Suppress volume UI popup
    VolumeManager.showNativeVolumeUI({ enabled: false });

    return () => {
      listener.remove();
      VolumeManager.showNativeVolumeUI({ enabled: true });
    };
  };

  // ─────────────────────────────────────────────────
  // Voice recognition handlers
  // ─────────────────────────────────────────────────

  const onSpeechResults = (e: SpeechResultsEvent) => {
    const text = e.value?.[0] ?? '';
    if (text) {
      setPartialText('');
      sendToClaud(text);
    }
  };

  const onSpeechPartialResults = (e: SpeechResultsEvent) => {
    const text = e.value?.[0] ?? '';
    setPartialText(text);
  };

  const onSpeechError = (e: SpeechErrorEvent) => {
    console.warn('Speech error:', e.error);
    setIsListening(false);
    stopPulseAnimation();
  };

  const onSpeechEnd = () => {
    setIsListening(false);
    stopPulseAnimation();
  };

  // ─────────────────────────────────────────────────
  // Core actions
  // ─────────────────────────────────────────────────

  const toggleListening = useCallback(async () => {
    if (isListening) {
      await Voice.stop();
      setIsListening(false);
      stopPulseAnimation();
    } else {
      // Stop any ongoing TTS
      Tts.stop();
      setPartialText('');
      Vibration.vibrate(50); // Haptic feedback: started listening

      try {
        await Voice.start('en-US');
        setIsListening(true);
        startPulseAnimation();
      } catch (err) {
        console.warn('Voice start error:', err);
      }
    }
  }, [isListening]);

  const sendToClaud = async (text: string) => {
    // Add to conversation
    const entry: ConversationEntry = {
      role: 'user',
      text,
      timestamp: Date.now(),
    };
    setConversation((prev) => [...prev, entry]);
    Vibration.vibrate(30); // Haptic: message sent

    // Send via Telegram
    const result = await telegramRef.current?.sendMessage(text);
    if (!result?.ok) {
      Alert.alert('Send Failed', result?.error ?? 'Unknown error');
    }
  };

  const handleClaudeResponse = (text: string) => {
    // Add to conversation
    const entry: ConversationEntry = {
      role: 'claude',
      text,
      timestamp: Date.now(),
    };
    setConversation((prev) => [...prev, entry]);

    // Speak the response
    speakResponse(text);
  };

  const speakResponse = (text: string) => {
    // Truncate very long responses for TTS
    const maxChars = 1500;
    let toSpeak = text;
    if (text.length > maxChars) {
      toSpeak = text.slice(0, maxChars) + '... Response truncated for speech.';
    }

    // Clean up code blocks and markdown for TTS
    toSpeak = toSpeak
      .replace(/```[\s\S]*?```/g, '... code block omitted ...')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/#{1,6}\s/g, '')
      .replace(/\*{1,2}([^*]+)\*{1,2}/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');

    Tts.speak(toSpeak);
  };

  // ─────────────────────────────────────────────────
  // Animations
  // ─────────────────────────────────────────────────

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.15,
          duration: 600,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  };

  const stopPulseAnimation = () => {
    pulseAnim.stopAnimation();
    Animated.timing(pulseAnim, {
      toValue: 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  // ─────────────────────────────────────────────────
  // Setup screen
  // ─────────────────────────────────────────────────

  const handleSetupComplete = async () => {
    setSetupError('');

    if (!botToken.trim() || !chatId.trim()) {
      setSetupError('Both fields are required');
      return;
    }

    // Verify the bot token
    const telegram = new TelegramService({
      botToken: botToken.trim(),
      chatId: chatId.trim(),
    });

    const verify = await telegram.verifyToken();
    if (!verify.ok) {
      setSetupError(`Invalid bot token: ${verify.error}`);
      return;
    }

    setBotName(verify.botName ?? '');

    // Save config
    await AsyncStorage.multiSet([
      [STORAGE_KEYS.BOT_TOKEN, botToken.trim()],
      [STORAGE_KEYS.CHAT_ID, chatId.trim()],
      [STORAGE_KEYS.SETUP_COMPLETE, 'true'],
    ]);

    await initServices(botToken.trim(), chatId.trim());
    setScreen('main');
  };

  // ─────────────────────────────────────────────────
  // Handle notification-based responses
  // ─────────────────────────────────────────────────

  // This is a placeholder for NotificationListenerService integration.
  // In the full native build, we'd register a service that intercepts
  // Telegram notifications and forwards them here. For now, polling
  // (via telegram.startPolling) handles response detection.
  //
  // To add notification listening, you'd create a native module:
  //   android/app/src/main/java/.../NotificationListener.java
  // that extends NotificationListenerService, filters for Telegram
  // notifications from the bot, and emits events to React Native.
  //
  // The Tasker approach (see tasker/README.md) handles this natively
  // and is recommended for initial testing.

  // ─────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  // ─── Setup Screen ───

  if (screen === 'setup') {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor="#0a0a0a" />

        <View style={styles.setupContent}>
          <Text style={styles.setupTitle}>Claude Voice Bridge</Text>
          <Text style={styles.setupSubtitle}>
            Connect to your Claude Code session via Telegram
          </Text>

          <View style={styles.setupCard}>
            <Text style={styles.setupStep}>
              1. Create a Telegram bot via @BotFather
            </Text>
            <Text style={styles.setupStep}>
              2. Run: claude --channels plugin:telegram@claude-plugins-official
            </Text>
            <Text style={styles.setupStep}>
              3. Pair with the bot in Telegram
            </Text>
            <Text style={styles.setupStep}>
              4. Enter your bot details below
            </Text>
          </View>

          <Text style={styles.inputLabel}>Bot Token</Text>
          <TextInput
            style={styles.input}
            value={botToken}
            onChangeText={setBotToken}
            placeholder="123456:ABC-DEF..."
            placeholderTextColor="#555"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.inputLabel}>Chat ID</Text>
          <TextInput
            style={styles.input}
            value={chatId}
            onChangeText={setChatId}
            placeholder="123456789"
            placeholderTextColor="#555"
            keyboardType="numeric"
          />

          <Text style={styles.chatIdHelp}>
            Send any message to your bot, then visit:{'\n'}
            https://api.telegram.org/bot{'<TOKEN>'}/getUpdates{'\n'}
            Look for "chat":{'{'}id":... {'}'} in the response.
          </Text>

          {setupError ? (
            <Text style={styles.errorText}>{setupError}</Text>
          ) : null}

          <TouchableOpacity
            style={styles.setupButton}
            onPress={handleSetupComplete}>
            <Text style={styles.setupButtonText}>Connect</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // ─── Main Screen ───

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0a" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: isConnected ? '#4ade80' : '#ef4444' },
            ]}
          />
          <Text style={styles.headerText}>
            {isConnected ? 'Connected' : 'Disconnected'}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            setScreen('setup');
            setIsConnected(false);
            telegramRef.current?.destroy();
          }}>
          <Text style={styles.headerSettings}>⚙</Text>
        </TouchableOpacity>
      </View>

      {/* Conversation log */}
      <ScrollView
        ref={scrollRef}
        style={styles.conversationContainer}
        contentContainerStyle={styles.conversationContent}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd()}>
        {conversation.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              Press the button below or your BT remote to start talking
            </Text>
          </View>
        ) : (
          conversation.map((entry, i) => (
            <View
              key={i}
              style={[
                styles.messageContainer,
                entry.role === 'user'
                  ? styles.userMessage
                  : styles.claudeMessage,
              ]}>
              <Text style={styles.messageRole}>
                {entry.role === 'user' ? 'You' : 'Claude'}
              </Text>
              <Text style={styles.messageText}>{entry.text}</Text>
            </View>
          ))
        )}
      </ScrollView>

      {/* Partial transcription */}
      {partialText ? (
        <View style={styles.partialContainer}>
          <Text style={styles.partialText}>{partialText}</Text>
        </View>
      ) : null}

      {/* Speaking indicator */}
      {isSpeaking ? (
        <View style={styles.speakingIndicator}>
          <Text style={styles.speakingText}>🔊 Claude is speaking...</Text>
          <TouchableOpacity onPress={() => Tts.stop()}>
            <Text style={styles.stopSpeaking}>Stop</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {/* PTT Button */}
      <View style={styles.buttonContainer}>
        <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
          <TouchableOpacity
            style={[
              styles.pttButton,
              isListening && styles.pttButtonActive,
            ]}
            onPress={toggleListening}
            activeOpacity={0.8}>
            <Text style={styles.pttIcon}>{isListening ? '⏹' : '🎤'}</Text>
            <Text style={styles.pttLabel}>
              {isListening ? 'Tap to send' : 'Tap to talk'}
            </Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </View>
  );
};

// ─────────────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#888',
    fontSize: 16,
  },

  // ─── Setup ───
  setupContent: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
  },
  setupTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
  },
  setupSubtitle: {
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    marginBottom: 32,
  },
  setupCard: {
    backgroundColor: '#161616',
    borderRadius: 12,
    padding: 16,
    marginBottom: 28,
    borderWidth: 1,
    borderColor: '#222',
  },
  setupStep: {
    color: '#aaa',
    fontSize: 13,
    lineHeight: 22,
    marginBottom: 4,
  },
  inputLabel: {
    color: '#ccc',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
    marginLeft: 2,
  },
  input: {
    backgroundColor: '#161616',
    borderRadius: 10,
    padding: 14,
    color: '#fff',
    fontSize: 15,
    borderWidth: 1,
    borderColor: '#333',
    marginBottom: 16,
    fontFamily: 'monospace',
  },
  chatIdHelp: {
    color: '#666',
    fontSize: 11,
    lineHeight: 16,
    marginBottom: 20,
    fontFamily: 'monospace',
  },
  errorText: {
    color: '#ef4444',
    fontSize: 13,
    marginBottom: 12,
    textAlign: 'center',
  },
  setupButton: {
    backgroundColor: '#d97706',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  setupButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },

  // ─── Header ───
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  headerText: {
    color: '#888',
    fontSize: 13,
  },
  headerSettings: {
    color: '#888',
    fontSize: 22,
  },

  // ─── Conversation ───
  conversationContainer: {
    flex: 1,
  },
  conversationContent: {
    padding: 16,
    paddingBottom: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 80,
  },
  emptyText: {
    color: '#555',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
  },
  messageContainer: {
    marginBottom: 12,
    borderRadius: 12,
    padding: 12,
    maxWidth: '88%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#1a3a2a',
    borderBottomRightRadius: 4,
  },
  claudeMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#1a1a2a',
    borderBottomLeftRadius: 4,
  },
  messageRole: {
    color: '#888',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  messageText: {
    color: '#e0e0e0',
    fontSize: 14,
    lineHeight: 20,
  },

  // ─── Partial transcription ───
  partialContainer: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    backgroundColor: '#111',
  },
  partialText: {
    color: '#d97706',
    fontSize: 14,
    fontStyle: 'italic',
  },

  // ─── Speaking indicator ───
  speakingIndicator: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 8,
    backgroundColor: '#0d1117',
  },
  speakingText: {
    color: '#4ade80',
    fontSize: 13,
  },
  stopSpeaking: {
    color: '#ef4444',
    fontSize: 13,
    fontWeight: '600',
  },

  // ─── PTT Button ───
  buttonContainer: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingBottom: 40,
    borderTopWidth: 1,
    borderTopColor: '#1a1a1a',
  },
  pttButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#333',
  },
  pttButtonActive: {
    backgroundColor: '#7f1d1d',
    borderColor: '#ef4444',
  },
  pttIcon: {
    fontSize: 36,
    marginBottom: 4,
  },
  pttLabel: {
    color: '#aaa',
    fontSize: 11,
    fontWeight: '600',
  },
});

export default App;
